<?php

namespace Paymenter\Extensions\Others\TelemetryBlock\Admin\Pages;

use Carbon\Carbon;
use Filament\Pages\Page;
use Illuminate\Support\Facades\DB;

class TelemetryStatsPage extends Page
{
    protected static string|\BackedEnum|null $navigationIcon = 'ri-shield-check-line';
    protected static string|\BackedEnum|null $activeNavigationIcon = 'ri-shield-check-fill';
    protected static ?string $navigationLabel = 'Telemetry Block';
    public static string|\UnitEnum|null $navigationGroup = 'System';
    protected static ?string $slug = 'telemetryblock-telemetry';
    protected static ?int $navigationSort = 98;

    protected string $view = 'telemetryblock::admin.pages.telemetry-stats';

    public bool $isBlocked          = false;
    public ?string $disabledSince   = null;
    public ?string $lastBlockedAt   = null;
    public int $realBlockedCount    = 0;
    public int $estimatedCount      = 0;
    public string $telemetryJson    = '';

    public function mount(): void
    {
        $settings = \App\Models\Extension::where('extension', 'TelemetryBlock')
            ->first()
            ?->settings
            ->pluck('value', 'key') ?? collect();

        $this->isBlocked = in_array($settings->get('block_telemetry', '1'), ['1', 1, true, 'true'], true);

        $marker = storage_path('app/telemetryblock_telemetry_disabled.json');
        if (file_exists($marker)) {
            $data = json_decode(file_get_contents($marker), true) ?? [];

            if (isset($data['disabled_since'])) {
                $at = Carbon::parse($data['disabled_since']);
                $this->disabledSince  = $at->format('d M Y, H:i');
                $this->estimatedCount = (int) $at->diffInDays(now());
            }

            $this->realBlockedCount = (int) ($data['real_blocked_count'] ?? 0);

            if (isset($data['last_blocked_at'])) {
                $this->lastBlockedAt = Carbon::parse($data['last_blocked_at'])->format('d M Y, H:i');
            }
        }

        $this->telemetryJson = json_encode($this->buildPayload(), JSON_PRETTY_PRINT);
    }

    private function buildPayload(): array
    {
        return [
            'version'         => config('app.version', 'unknown'),
            'php_version'     => phpversion(),
            'database_counts' => [
                'invoices'   => [
                    'count' => DB::table('invoices')->count(),
                    'paid'  => DB::table('invoices')->where('status', 'paid')->count(),
                ],
                'services'   => [
                    'count'  => DB::table('services')->count(),
                    'active' => DB::table('services')->where('status', 'active')->count(),
                ],
                'products'   => ['count' => DB::table('products')->count()],
                'users'      => [
                    'count'  => DB::table('users')->count(),
                    'admins' => DB::table('users')->whereNotNull('role_id')->count(),
                ],
                'extensions' => [
                    'count'  => DB::table('extensions')->count(),
                    'active' => DB::table('extensions')->where('enabled', true)->pluck('extension')->toArray(),
                ],
            ],
        ];
    }

    public static function canAccess(): bool
    {
        return auth()->check() && ! is_null(auth()->user()->role);
    }
}
