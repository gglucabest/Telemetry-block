<div class="mb-6">
    <h2 class="text-sm font-semibold uppercase tracking-widest text-base/70 mb-4">
        {{ __($sectionTitle) }}
    </h2>

    <div class="grid grid-cols-2 lg:grid-cols-4 gap-4">

        {{-- Active Services --}}
        @if($showActiveServices)
        <div class="bg-background-secondary border border-neutral rounded-lg p-6">
            <div class="flex items-center justify-between mb-2">
                <span class="text-sm text-base/70">{{ __('Active Services') }}</span>
                <svg class="w-5 h-5 text-primary-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                          d="M5 12h14M12 5l7 7-7 7"/>
                </svg>
            </div>
            <p class="text-3xl font-bold text-primary-100">{{ $activeServices }}</p>
        </div>
        @endif

        {{-- Pending Invoices --}}
        @if($showPendingInvoices)
        <a href="{{ route('invoices') }}" wire:navigate
           class="bg-background-secondary border border-neutral rounded-lg p-6 block transition-colors hover:border-primary/40">
            <div class="flex items-center justify-between mb-2">
                <span class="text-sm text-base/70">{{ __('Pending Invoices') }}</span>
                <svg class="w-5 h-5 text-warning" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                          d="M9 14l6-6m-5.5.5h.01m4.99 5h.01M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16l3.5-2 3.5 2 3.5-2 3.5 2z"/>
                </svg>
            </div>
            <div class="flex items-center gap-2">
                <p class="text-3xl font-bold text-primary-100">{{ $pendingInvoices }}</p>
                @if($pendingInvoices > 0)
                    <span class="px-2 py-0.5 text-xs rounded-full bg-warning/20 text-warning font-semibold">!</span>
                @endif
            </div>
        </a>
        @endif

        {{-- Open Tickets --}}
        @if($showOpenTickets)
        <a href="{{ route('tickets') }}" wire:navigate
           class="bg-background-secondary border border-neutral rounded-lg p-6 block transition-colors hover:border-primary/40">
            <div class="flex items-center justify-between mb-2">
                <span class="text-sm text-base/70">{{ __('Open Tickets') }}</span>
                <svg class="w-5 h-5 text-primary-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                          d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"/>
                </svg>
            </div>
            <p class="text-3xl font-bold text-primary-100">{{ $openTickets }}</p>
        </a>
        @endif

        {{-- Next Renewal --}}
        @if($showNextRenewal)
        <div class="bg-background-secondary border border-neutral rounded-lg p-6">
            <div class="flex items-center justify-between mb-2">
                <span class="text-sm text-base/70">{{ __('Next Renewal') }}</span>
                <svg class="w-5 h-5 text-success" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                          d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/>
                </svg>
            </div>
            @if($nextRenewal && $nextRenewal->expires_at)
                <p class="text-2xl font-bold text-primary-100">
                    {{ $nextRenewal->expires_at->format('d M Y') }}
                </p>
                <p class="text-xs text-base/50 mt-1">{{ $nextRenewal->expires_at->diffForHumans() }}</p>
            @else
                <p class="text-3xl font-bold text-primary-100">—</p>
            @endif
        </div>
        @endif

    </div>
</div>
