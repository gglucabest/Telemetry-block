<x-filament-panels::page>

    {{-- Status header --}}
    <x-filament::section>
        <x-slot name="heading">Telemetry Blocking</x-slot>
        <x-slot name="description">
            Outbound statistics requests to <code>https://api.paymenter.org/statistics</code> are intercepted
            at the HTTP layer. Toggle blocking on or off via the <strong>Block Telemetry</strong> setting on the extension configuration page.
        </x-slot>

        <div class="flex flex-wrap items-center gap-6">
            <div class="flex items-center gap-3">
                <span class="text-sm font-medium text-gray-600 dark:text-gray-400">HTTP guard</span>
                @if ($this->isBlocked)
                    <x-filament::badge color="success" icon="ri-shield-check-fill">Active</x-filament::badge>
                @else
                    <x-filament::badge color="danger" icon="ri-shield-cross-line">Disabled</x-filament::badge>
                @endif
            </div>

            @if ($this->disabledSince)
                <div class="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
                    <x-ri-calendar-check-line class="size-4 shrink-0" />
                    <span>Tracking since <strong class="text-gray-900 dark:text-white">{{ $this->disabledSince }}</strong></span>
                </div>
            @endif
        </div>
    </x-filament::section>

    {{-- Stats row --}}
    <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">

        <x-filament::section>
            <div class="flex items-center justify-between mb-2">
                <span class="text-sm text-gray-500 dark:text-gray-400">Confirmed blocked</span>
                <x-ri-shield-check-fill class="size-5 text-success-500" />
            </div>
            <p class="text-3xl font-bold">{{ number_format($this->realBlockedCount) }}</p>
            <p class="text-xs text-gray-400 dark:text-gray-500 mt-1">intercepted by HTTP guard</p>
        </x-filament::section>

        <x-filament::section>
            <div class="flex items-center justify-between mb-2">
                <span class="text-sm text-gray-500 dark:text-gray-400">Estimated blocked</span>
                <x-ri-bar-chart-2-line class="size-5 text-primary-500" />
            </div>
            <p class="text-3xl font-bold">{{ number_format($this->estimatedCount) }}</p>
            <p class="text-xs text-gray-400 dark:text-gray-500 mt-1">~1 per day since tracking</p>
        </x-filament::section>

        <x-filament::section>
            <div class="flex items-center justify-between mb-2">
                <span class="text-sm text-gray-500 dark:text-gray-400">Last intercepted</span>
                <x-ri-time-line class="size-5 text-warning-500" />
            </div>
            <p class="text-lg font-bold">{{ $this->lastBlockedAt ?? '—' }}</p>
            <p class="text-xs text-gray-400 dark:text-gray-500 mt-1">confirmed real block</p>
        </x-filament::section>

    </div>

    {{-- Payload preview --}}
    <x-filament::section collapsible collapsed>
        <x-slot name="heading">What would have been sent</x-slot>
        <x-slot name="description">
            Live snapshot of the data Paymenter collects for its telemetry ping.
            This is the exact payload that is now blocked.
        </x-slot>

        <pre style="background:#0d1117;color:#e6edf3;border-radius:.5rem;padding:1rem;font-size:.75rem;line-height:1.6;overflow-x:auto;white-space:pre-wrap;border:1px solid rgba(255,255,255,.08);">{{ $this->telemetryJson }}</pre>
    </x-filament::section>

</x-filament-panels::page>
