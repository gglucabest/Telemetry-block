<?php

namespace Paymenter\Extensions\Others\TelemetryBlock;

use App\Classes\Extension\Extension;
use GuzzleHttp\Promise\Create;
use GuzzleHttp\Psr7\Response as Psr7Response;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Event;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\View;
use Psr\Http\Message\RequestInterface;

class TelemetryBlock extends Extension
{
    private static bool $httpGuardRegistered = false;

    public function getConfig($values = [])
    {
        return [
            [
                'name'        => 'block_telemetry',
                'type'        => 'checkbox',
                'label'       => 'Block Telemetry',
                'description' => 'Intercept outbound statistics requests to api.paymenter.org/statistics at the HTTP layer.',
                'default'     => true,
            ],
            [
                'name'        => 'section_title',
                'type'        => 'text',
                'label'       => 'Section Title',
                'default'     => 'Account Overview',
                'description' => 'Title shown above the stats cards on the dashboard.',
            ],
            [
                'name'        => 'show_active_services',
                'type'        => 'checkbox',
                'label'       => 'Show Active Services',
                'description' => 'Display the active services count card.',
                'default'     => true,
            ],
            [
                'name'        => 'show_pending_invoices',
                'type'        => 'checkbox',
                'label'       => 'Show Pending Invoices',
                'description' => 'Display the pending invoices count card.',
                'default'     => true,
            ],
            [
                'name'        => 'show_open_tickets',
                'type'        => 'checkbox',
                'label'       => 'Show Open Tickets',
                'description' => 'Display the open tickets count card.',
                'default'     => true,
            ],
            [
                'name'        => 'show_next_renewal',
                'type'        => 'checkbox',
                'label'       => 'Show Next Renewal',
                'description' => 'Display the next renewal date card.',
                'default'     => true,
            ],
        ];
    }

    public function boot()
    {
        View::addNamespace('telemetryblock', __DIR__ . '/resources/views');

        $settings = \App\Models\Extension::where('extension', 'TelemetryBlock')
            ->first()
            ?->settings
            ->pluck('value', 'key') ?? collect();

        $bool = fn ($key, $default = '1') => in_array($settings->get($key, $default), ['1', 1, true, 'true'], true);

        if ($bool('block_telemetry')) {
            $this->registerHttpGuard();
            $this->initMarker();
        }

        Event::listen('pages.dashboard', function () use ($bool, $settings) {
            $user = Auth::user();
            if (! $user) {
                return;
            }

            $showActiveServices  = $bool('show_active_services');
            $showPendingInvoices = $bool('show_pending_invoices');
            $showOpenTickets     = $bool('show_open_tickets');
            $showNextRenewal     = $bool('show_next_renewal');
            $sectionTitle        = $settings->get('section_title') ?: 'Account Overview';

            if (! $showActiveServices && ! $showPendingInvoices && ! $showOpenTickets && ! $showNextRenewal) {
                return null;
            }

            $activeServices  = $showActiveServices  ? $user->services()->where('status', 'active')->count() : null;
            $pendingInvoices = $showPendingInvoices ? $user->invoices()->where('status', 'pending')->count() : null;
            $openTickets     = $showOpenTickets     ? $user->tickets()->where('status', '!=', 'closed')->count() : null;
            $nextRenewal     = $showNextRenewal
                ? $user->services()->where('status', 'active')->whereNotNull('expires_at')->orderBy('expires_at')->first()
                : null;

            return [
                'view' => view('telemetryblock::dashboard', compact(
                    'activeServices',
                    'pendingInvoices',
                    'openTickets',
                    'nextRenewal',
                    'showActiveServices',
                    'showPendingInvoices',
                    'showOpenTickets',
                    'showNextRenewal',
                    'sectionTitle'
                )),
                'priority' => -10,
            ];
        });
    }

    private function registerHttpGuard(): void
    {
        if (static::$httpGuardRegistered) {
            return;
        }
        static::$httpGuardRegistered = true;

        Http::globalMiddleware(function (callable $handler) {
            return function (RequestInterface $request, array $options) use ($handler) {
                if (str_contains((string) $request->getUri(), 'api.paymenter.org/statistics')) {
                    $this->recordRealBlock();
                    return Create::promiseFor(new Psr7Response(200, [], '{"status":"blocked_by_telemetryblock"}'));
                }

                return $handler($request, $options);
            };
        });
    }

    private function recordRealBlock(): void
    {
        $marker = storage_path('app/telemetryblock_telemetry_disabled.json');
        $data   = file_exists($marker) ? (json_decode(file_get_contents($marker), true) ?? []) : [];

        $data['disabled_since']    ??= now()->toISOString();
        $data['real_blocked_count']  = ($data['real_blocked_count'] ?? 0) + 1;
        $data['last_blocked_at']     = now()->toISOString();

        @file_put_contents($marker, json_encode($data, JSON_PRETTY_PRINT));
    }

    private function initMarker(): void
    {
        $marker = storage_path('app/telemetryblock_telemetry_disabled.json');
        if (! file_exists($marker)) {
            @file_put_contents($marker, json_encode([
                'disabled_since'    => now()->toISOString(),
                'real_blocked_count' => 0,
            ], JSON_PRETTY_PRINT));
        }
    }
}
